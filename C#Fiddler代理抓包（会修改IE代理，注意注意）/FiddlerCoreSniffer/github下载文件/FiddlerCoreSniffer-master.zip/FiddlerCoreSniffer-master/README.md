FiddlerCore Sniffer
===============

Description
------------

Simple http traffic sniffer based on FiddlerCore library.

Usage
------------

This console application accepts only hostname parameter. If no hostname is provided, *localhost* will be assumed.

    FiddlerCoreSniffer.exe hostname
